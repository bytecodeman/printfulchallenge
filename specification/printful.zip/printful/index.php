<?php
// Tony Silvestri
// 11/4/21

require("vendor/autoload.php");
require_once('./app/Application.php');

(new Homework\Application())->run();
