<?php

require_once('./app/Application.php');

(new Homework\Application())->run();
